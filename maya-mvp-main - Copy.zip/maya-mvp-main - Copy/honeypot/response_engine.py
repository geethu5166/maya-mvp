import json
import smtplib
import time
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

from core.event_bus import EVENT_LOG, RESPONSE_LOG, execute_response_plan, load_json_lines


def send_email_alert(event, email_to="geetesh5166@gmail.com"):
    """Send a simple critical alert email."""
    try:
        email_from = "your_email@gmail.com"
        email_password = "your_app_password"

        msg = MIMEMultipart()
        msg["From"] = email_from
        msg["To"] = email_to
        msg["Subject"] = f"[MAYA ALERT] {event['severity']} {event['type']} detected"

        body = f"""
MAYA Autonomous Security Platform
================================

Critical event detected and processed automatically.

Event ID: {event['event_id']}
Type: {event['type']}
Severity: {event['severity']}
Attacker IP: {event['attacker_ip']}

Summary:
{event['report']['executive_summary']}

Recommended actions:
{chr(10).join('- ' + item for item in event['decision']['recommended_actions'])}
        """

        msg.attach(MIMEText(body, "plain"))

        server = smtplib.SMTP("smtp.gmail.com", 587)
        server.starttls()
        server.login(email_from, email_password)
        server.send_message(msg)
        server.quit()
        return True
    except Exception:
        return False


def get_processed_event_ids():
    processed = set()
    for response in load_json_lines(RESPONSE_LOG):
        event_id = response.get("event_id")
        if event_id:
            processed.add(event_id)
    return processed


def watch_and_respond():
    """
    Watches the central event stream and executes response plans.
    The event bus handles ingestion, enrichment, correlation, and decisioning.
    This worker performs the response and reporting side of the same pipeline.
    """
    print("[MAYA] Autonomous Response Engine started")
    print("[MAYA] Watching central event stream...")

    while True:
        try:
            processed_ids = get_processed_event_ids()
            for event in load_json_lines(EVENT_LOG):
                event_id = event.get("event_id")
                if not event_id or event_id in processed_ids:
                    continue

                print(f"\n[MAYA] Executing response plan for {event.get('type')} from {event.get('attacker_ip')}")
                response_record = execute_response_plan(event)
                print(f"[MAYA RESPONSE] {json.dumps(response_record)}")

                if event.get("severity") == "CRITICAL":
                    sent = send_email_alert(event)
                    print(f"[MAYA] Critical alert email status: {'sent' if sent else 'failed'}")

        except Exception:
            pass

        time.sleep(1)


if __name__ == "__main__":
    watch_and_respond()
