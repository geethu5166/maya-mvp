import os
import requests


def _default_playbook(event):
    classification = event.get("classification", {})
    decision = event.get("decision", {})
    report = event.get("report", {})
    severity = event.get("severity", "LOW")

    return {
        "agent_status": "deterministic-playbook",
        "forensic_investigation": [
            "Collect all events associated with the same attacker IP and campaign fingerprint.",
            "Validate whether any real assets mirror the decoy surface that was touched.",
            "Check for credential overlap between decoy submissions and real access-control systems.",
        ],
        "patch_recommendations": decision.get("patch_recommendations", []),
        "containment_steps": decision.get("recommended_actions", []),
        "compliance_report": report.get("compliance_mapping", []),
        "recommended_mttr": "Near-zero with autonomous workflow" if severity in {"HIGH", "CRITICAL"} else "Minutes",
        "explainable_summary": classification.get("explainable_reasons", []),
    }


def run_agentic_investigation(event):
    """
    Frontier-ready agent layer.
    Uses a deterministic playbook by default and can call an
    OpenAI-compatible or Mistral-compatible endpoint if configured.
    """
    endpoint = os.getenv("MAYA_AGENT_API_URL")
    api_key = os.getenv("MAYA_AGENT_API_KEY")
    model = os.getenv("MAYA_AGENT_MODEL", "mistral-large-latest")

    if not endpoint or not api_key:
        return _default_playbook(event)

    prompt = {
        "event": {
            "type": event.get("type"),
            "severity": event.get("severity"),
            "attacker_ip": event.get("attacker_ip"),
            "classification": event.get("classification"),
            "correlation": event.get("correlation"),
            "enrichment": event.get("enrichment"),
        },
        "task": (
            "Act as MAYA's autonomous SOC agent. Produce a JSON object with "
            "forensic_investigation, patch_recommendations, containment_steps, "
            "compliance_report, recommended_mttr, and explainable_summary."
        ),
    }

    try:
        response = requests.post(
            endpoint,
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            json={
                "model": model,
                "messages": [
                    {"role": "system", "content": "You are MAYA, an autonomous cybersecurity investigation agent."},
                    {"role": "user", "content": str(prompt)},
                ],
                "temperature": 0.2,
            },
            timeout=12,
        )
        response.raise_for_status()
        data = response.json()
        choice = (data.get("choices") or [{}])[0]
        content = choice.get("message", {}).get("content", "")
        return {
            "agent_status": "remote-llm",
            "raw_content": content,
            **_default_playbook(event),
        }
    except Exception as exc:
        fallback = _default_playbook(event)
        fallback["agent_status"] = f"fallback-after-error: {exc}"
        return fallback
