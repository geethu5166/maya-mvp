from collections import Counter

try:
    import networkx as nx
except Exception:
    nx = None


def _fallback_graph_summary(events, attacker_ip):
    touched_honeypots = sorted({event.get("honeypot", "UNKNOWN") for event in events if event.get("attacker_ip") == attacker_ip})
    touched_paths = sorted({event.get("path", "") for event in events if event.get("attacker_ip") == attacker_ip and event.get("path")})
    return {
        "graph_engine": "fallback",
        "nodes": len(touched_honeypots) + len(touched_paths) + 1,
        "edges": len(touched_honeypots) + len(touched_paths),
        "honeypots_touched": touched_honeypots,
        "paths_touched": touched_paths[:5],
        "lateral_movement_score": max(0, len(touched_honeypots) - 1) * 25,
        "possible_lateral_movement": len(touched_honeypots) > 1,
    }


def analyze_attack_graph(events, attack):
    """
    Build a graph view of the attack campaign to surface
    multi-surface movement and campaign complexity.
    """
    attacker_ip = attack.get("attacker_ip", "")
    attacker_events = [event for event in events if event.get("attacker_ip") == attacker_ip]

    if not attacker_events:
        return {
            "graph_engine": "none",
            "nodes": 0,
            "edges": 0,
            "honeypots_touched": [],
            "paths_touched": [],
            "lateral_movement_score": 0,
            "possible_lateral_movement": False,
        }

    if nx is None:
        return _fallback_graph_summary(attacker_events, attacker_ip)

    graph = nx.MultiDiGraph()
    graph.add_node(attacker_ip, kind="attacker")

    for event in attacker_events:
        honeypot = event.get("honeypot", "UNKNOWN")
        attack_type = event.get("type", "UNKNOWN")
        graph.add_node(honeypot, kind="honeypot")
        graph.add_edge(attacker_ip, honeypot, attack_type=attack_type, timestamp=event.get("timestamp"))

        target = event.get("path") or event.get("username_tried") or event.get("credentials") or attack_type
        target_node = f"{honeypot}:{target}"
        graph.add_node(target_node, kind="target")
        graph.add_edge(honeypot, target_node, attack_type=attack_type)

    honeypots_touched = sorted(
        node for node, data in graph.nodes(data=True)
        if data.get("kind") == "honeypot"
    )
    target_counter = Counter(
        node for node, data in graph.nodes(data=True)
        if data.get("kind") == "target"
    )
    score = max(0, len(honeypots_touched) - 1) * 35 + min(len(target_counter), 5) * 6

    return {
        "graph_engine": "networkx",
        "nodes": graph.number_of_nodes(),
        "edges": graph.number_of_edges(),
        "honeypots_touched": honeypots_touched,
        "paths_touched": list(target_counter.keys())[:5],
        "lateral_movement_score": min(score, 100),
        "possible_lateral_movement": len(honeypots_touched) > 1,
    }
