import datetime
import hashlib
import json
import os
import subprocess
import uuid
from pathlib import Path

import requests
from core.agentic_ai import run_agentic_investigation
from core.continuous_learning import queue_for_learning
from core.graph_analytics import analyze_attack_graph

from detection.geolocate import get_location

try:
    from detection.threat_intelligence import check_ip_full
except Exception:
    check_ip_full = None

BASE_DIR = Path(__file__).resolve().parent.parent
LOG_DIR = BASE_DIR / "logs"
REPORT_DIR = LOG_DIR / "reports"
RAW_ATTACK_LOG = LOG_DIR / "attacks.log"
EVENT_LOG = LOG_DIR / "events.log"
RESPONSE_LOG = LOG_DIR / "responses.log"
BLOCKED_IPS = LOG_DIR / "blocked_ips.txt"

MITRE_MAP = {
    "SSH_BRUTE_FORCE": {"technique": "T1110.001", "name": "Password Guessing"},
    "WEB_CREDENTIAL_HARVEST": {"technique": "T1056", "name": "Input Capture"},
    "WEB_SCAN": {"technique": "T1595", "name": "Active Scanning"},
    "WEB_RECON": {"technique": "T1595.001", "name": "Scanning IP Blocks"},
    "RDP_BRUTE_FORCE": {"technique": "T1110", "name": "Brute Force"},
}

CVE_MAP = {
    "SSH_BRUTE_FORCE": [
        {"cve": "CVE-2024-6387", "summary": "OpenSSH race-condition risk on unpatched hosts"},
        {"cve": "CVE-2023-38408", "summary": "OpenSSH agent forwarding abuse path"},
    ],
    "WEB_CREDENTIAL_HARVEST": [
        {"cve": "CVE-2021-44228", "summary": "Common web stack exposure still abused in opportunistic campaigns"},
        {"cve": "CVE-2023-34362", "summary": "MOVEit-style credential and data theft campaigns"},
    ],
    "WEB_SCAN": [
        {"cve": "CVE-2023-3519", "summary": "Appliance-facing scanning for internet-exposed remote access"},
    ],
}

DEFAULT_ACTIONS = {
    "CRITICAL": ["Block attacker IP", "Open forensic investigation", "Generate compliance report"],
    "HIGH": ["Block attacker IP", "Increase monitoring", "Generate operator summary"],
    "MEDIUM": ["Monitor closely", "Correlate with prior activity"],
    "LOW": ["Log and retain telemetry"],
}


def ensure_paths():
    LOG_DIR.mkdir(exist_ok=True)
    REPORT_DIR.mkdir(exist_ok=True)


def append_json_line(path: Path, payload: dict):
    ensure_paths()
    with path.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(payload) + "\n")


def load_json_lines(path: Path):
    if not path.exists():
        return []
    items = []
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            line = line.strip()
            if not line:
                continue
            try:
                items.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return items


def is_private_ip(ip: str) -> bool:
    return ip.startswith(("127.", "10.", "192.168.", "172.16.", "172.17.", "172.18.", "172.19."))


def normalize_attack(raw_attack: dict) -> dict:
    timestamp = raw_attack.get("timestamp") or datetime.datetime.utcnow().isoformat()
    attack = dict(raw_attack)
    attack.setdefault("timestamp", timestamp)
    attack.setdefault("severity", "LOW")
    attack.setdefault("honeypot", "UNKNOWN")
    attack.setdefault("type", "UNKNOWN")
    attack.setdefault("attacker_ip", "0.0.0.0")
    attack.setdefault("source", "honeypot")
    return attack


def lookup_abuseipdb(ip: str) -> dict:
    api_key = os.getenv("ABUSEIPDB_API_KEY")
    if not api_key or is_private_ip(ip):
        return {"status": "not_configured"}

    try:
        response = requests.get(
            "https://api.abuseipdb.com/api/v2/check",
            headers={"Key": api_key, "Accept": "application/json"},
            params={"ipAddress": ip, "maxAgeInDays": "90"},
            timeout=5,
        )
        response.raise_for_status()
        data = response.json().get("data", {})
        return {
            "status": "ok",
            "abuse_confidence_score": data.get("abuseConfidenceScore", 0),
            "usage_type": data.get("usageType", "unknown"),
            "isp": data.get("isp", "unknown"),
            "domain": data.get("domain", ""),
            "country_code": data.get("countryCode", ""),
            "total_reports": data.get("totalReports", 0),
        }
    except Exception as exc:
        return {"status": "error", "message": str(exc)}


def correlate_cves(attack_type: str):
    return CVE_MAP.get(attack_type, [])


def historical_frequency(ip: str, attack_type: str) -> dict:
    raw_events = load_json_lines(RAW_ATTACK_LOG)
    now = datetime.datetime.utcnow()
    total_for_ip = 0
    total_for_signature = 0
    last_24h = 0

    for event in raw_events:
        try:
            event_time = datetime.datetime.fromisoformat(event.get("timestamp", ""))
        except Exception:
            event_time = now

        if event.get("attacker_ip") == ip:
            total_for_ip += 1
            if now - event_time <= datetime.timedelta(hours=24):
                last_24h += 1

        if event.get("attacker_ip") == ip and event.get("type") == attack_type:
            total_for_signature += 1

    return {
        "total_attacks_from_ip": total_for_ip,
        "same_attack_type_count": total_for_signature,
        "attacks_last_24h": last_24h,
        "repeat_offender": total_for_ip > 1,
    }


def build_explanation(attack: dict, historical: dict, intel: dict) -> list:
    reasons = []
    attack_type = attack.get("type", "UNKNOWN")

    if attack_type == "SSH_BRUTE_FORCE":
        attempted_user = attack.get("username_tried", "unknown")
        reasons.append(f"SSH brute-force behavior observed through repeated login attempts against user {attempted_user}.")
        if attack.get("password_tried"):
            reasons.append("Credential guessing pattern captured directly from the honeypot authentication flow.")
    elif attack_type == "WEB_CREDENTIAL_HARVEST":
        reasons.append("Credential harvesting confirmed because the attacker submitted credentials into the decoy login flow.")
    elif attack_type == "WEB_SCAN":
        reasons.append("Reconnaissance indicators detected through probing of common sensitive web paths.")
    else:
        reasons.append("Suspicious interaction detected by the deception layer.")

    if historical.get("repeat_offender"):
        reasons.append(f"Same source has appeared {historical['total_attacks_from_ip']} times in captured telemetry.")

    geolocation = intel.get("geolocation", {})
    if geolocation.get("country"):
        reasons.append(f"Source geolocated to {geolocation.get('city', 'Unknown city')}, {geolocation['country']}.")

    threat_tags = intel.get("threat_tags", [])
    if threat_tags:
        reasons.append(f"Threat-intel indicators present: {', '.join(threat_tags[:3])}.")

    mitre = MITRE_MAP.get(attack_type)
    if mitre:
        reasons.append(f"Mapped to MITRE ATT&CK {mitre['technique']} ({mitre['name']}).")

    return reasons


def classify_attack(attack: dict, historical: dict, intel: dict, cves: list) -> dict:
    severity = attack.get("severity", "LOW")
    base_confidence = {"LOW": 45, "MEDIUM": 68, "HIGH": 84, "CRITICAL": 94}.get(severity, 50)
    base_confidence += min(historical.get("same_attack_type_count", 0) * 2, 6)
    base_confidence += min(intel.get("risk_score", 0) // 10, 5)
    confidence = min(base_confidence, 99)
    mitre = MITRE_MAP.get(attack.get("type", ""), {"technique": "T0000", "name": "Unknown Technique"})

    return {
        "confidence": confidence,
        "threat_level": severity,
        "mitre_technique": mitre["technique"],
        "mitre_name": mitre["name"],
        "cve_candidates": cves,
        "explainable_reasons": build_explanation(attack, historical, intel),
    }


def correlate_attack(attack: dict, historical: dict) -> dict:
    fingerprint_seed = f"{attack.get('attacker_ip')}|{attack.get('type')}|{attack.get('honeypot')}"
    fingerprint = hashlib.sha256(fingerprint_seed.encode()).hexdigest()[:16]
    graph = analyze_attack_graph(load_json_lines(RAW_ATTACK_LOG), attack)
    return {
        "campaign_fingerprint": fingerprint,
        "repeat_offender": historical["repeat_offender"],
        "historical_attack_frequency": historical,
        "attack_graph": graph,
    }


def decide_response(attack: dict, classification: dict, intel: dict) -> dict:
    severity = attack.get("severity", "LOW")
    recommended_actions = list(DEFAULT_ACTIONS.get(severity, DEFAULT_ACTIONS["LOW"]))
    autonomous_block = severity in {"HIGH", "CRITICAL"} and not is_private_ip(attack.get("attacker_ip", ""))
    abuse = intel.get("abuseipdb", {})

    if abuse.get("status") == "ok" and abuse.get("abuse_confidence_score", 0) >= 70:
        recommended_actions.append("Escalate risk because AbuseIPDB confidence is high")

    graph = classification.get("attack_graph") or {}
    if graph.get("possible_lateral_movement"):
        recommended_actions.append("Investigate possible multi-system movement path")

    return {
        "priority": severity,
        "recommended_actions": recommended_actions,
        "autonomous_block": autonomous_block,
        "autonomous_forensics": True,
        "agent_mode": "autonomous-playbook",
        "recommended_firewall_rule": f"iptables -A INPUT -s {attack.get('attacker_ip', '0.0.0.0')} -j DROP",
        "patch_recommendations": build_patch_recommendations(classification.get("cve_candidates", [])),
    }


def build_patch_recommendations(cves: list) -> list:
    if not cves:
        return ["Review exposed services and enforce least privilege on internet-facing assets."]
    return [f"Assess exposure for {item['cve']} and patch or isolate any affected service." for item in cves]


def build_report(event: dict) -> dict:
    attack_type = event.get("type", "UNKNOWN")
    ip = event.get("attacker_ip", "0.0.0.0")
    severity = event.get("severity", "LOW")
    country = event.get("enrichment", {}).get("geolocation", {}).get("country", "Unknown")
    executive_summary = (
        f"{severity} {attack_type} activity detected from {ip}. "
        f"Source attribution currently points to {country}. "
        f"MAYA correlated the event, produced response actions, and generated compliance context automatically."
    )

    return {
        "executive_summary": executive_summary,
        "compliance_mapping": [
            "ISO 27001 A.5.24 Incident management planning",
            "ISO 27001 A.8.16 Monitoring activities",
            "GDPR Article 32 Security of processing",
        ],
        "forensic_questions": [
            "Was the targeted asset exposed to the internet intentionally?",
            "Has this source interacted with any other honeypot surface in the last 24 hours?",
            "Do any real credentials overlap with captured credential patterns?",
        ],
    }


def enrich_attack(attack: dict) -> dict:
    ip = attack.get("attacker_ip", "0.0.0.0")
    geo = get_location(ip)

    intel = {
        "geolocation": geo,
        "country": geo.get("country", "Unknown"),
        "city": geo.get("city", "Unknown"),
        "asn": "Unknown",
        "threat_tags": [],
        "risk_score": 0,
        "abuseipdb": lookup_abuseipdb(ip),
    }

    if check_ip_full and not is_private_ip(ip):
        try:
            ip_intel = check_ip_full(ip)
            intel["asn"] = ip_intel.get("geolocation", {}).get("org", "Unknown")
            intel["threat_tags"] = ip_intel.get("threat_tags", [])
            intel["risk_score"] = ip_intel.get("risk_score", 0)
            intel["network_info"] = ip_intel
        except Exception:
            intel["network_info"] = {"verdict": "unavailable"}
    else:
        intel["network_info"] = {"verdict": "local_or_unavailable"}

    intel["cve_correlation"] = correlate_cves(attack.get("type", "UNKNOWN"))
    intel["historical"] = historical_frequency(ip, attack.get("type", "UNKNOWN"))
    return intel


def publish_event(raw_attack: dict) -> dict:
    attack = normalize_attack(raw_attack)
    attack["event_id"] = attack.get("event_id", str(uuid.uuid4()))
    append_json_line(RAW_ATTACK_LOG, attack)

    enrichment = enrich_attack(attack)
    classification = classify_attack(attack, enrichment["historical"], enrichment, enrichment["cve_correlation"])
    correlation = correlate_attack(attack, enrichment["historical"])
    classification["attack_graph"] = correlation["attack_graph"]
    decision = decide_response(attack, classification, enrichment)
    report = build_report({
        **attack,
        "enrichment": enrichment,
    })

    event = {
        **attack,
        "pipeline_state": "DECISION_READY",
        "enrichment": enrichment,
        "classification": classification,
        "correlation": correlation,
        "decision": decision,
        "report": report,
        "explanation": classification["explainable_reasons"],
        "response_status": "PENDING",
    }
    event["agentic_ai"] = run_agentic_investigation(event)
    event["continuous_learning"] = queue_for_learning(event)
    append_json_line(EVENT_LOG, event)
    return event


def get_blocked_ips():
    if not BLOCKED_IPS.exists():
        return set()
    with BLOCKED_IPS.open("r", encoding="utf-8") as handle:
        return {line.strip() for line in handle if line.strip()}


def block_ip(ip: str):
    if not ip or is_private_ip(ip):
        return False, "Local or empty IP skipped"

    blocked = get_blocked_ips()
    if ip in blocked:
        return False, "Already blocked"

    try:
        completed = subprocess.run(
            ["sudo", "iptables", "-A", "INPUT", "-s", ip, "-j", "DROP"],
            capture_output=True,
            timeout=5,
        )
        if completed.returncode != 0:
            return False, completed.stderr.decode("utf-8", errors="ignore") or "iptables command failed"

        with BLOCKED_IPS.open("a", encoding="utf-8") as handle:
            handle.write(ip + "\n")
        return True, f"Firewall rule applied for {ip}"
    except Exception as exc:
        return False, str(exc)


def write_compliance_report(event: dict) -> str:
    ensure_paths()
    filename = REPORT_DIR / f"report_{event['event_id']}.json"
    payload = {
        "generated_at": datetime.datetime.utcnow().isoformat(),
        "event_id": event["event_id"],
        "attack_type": event.get("type"),
        "severity": event.get("severity"),
        "executive_summary": event["report"]["executive_summary"],
        "compliance_mapping": event["report"]["compliance_mapping"],
        "patch_recommendations": event["decision"]["patch_recommendations"],
        "explanation": event["explanation"],
    }
    with filename.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
    return str(filename)


def execute_response_plan(event: dict) -> dict:
    decision = event.get("decision", {})
    blocked = {"status": "skipped", "details": "No block requested"}
    if decision.get("autonomous_block"):
        success, details = block_ip(event.get("attacker_ip", ""))
        blocked = {
            "status": "success" if success else "failed",
            "details": details,
            "rule": decision.get("recommended_firewall_rule"),
        }

    report_path = write_compliance_report(event)
    response_record = {
        "event_id": event["event_id"],
        "timestamp": datetime.datetime.utcnow().isoformat(),
        "attack_type": event.get("type"),
        "attacker_ip": event.get("attacker_ip"),
        "actions_taken": decision.get("recommended_actions", []),
        "firewall": blocked,
        "patch_recommendations": decision.get("patch_recommendations", []),
        "report_path": report_path,
        "agent_mode": decision.get("agent_mode", "autonomous-playbook"),
    }
    append_json_line(RESPONSE_LOG, response_record)
    return response_record
