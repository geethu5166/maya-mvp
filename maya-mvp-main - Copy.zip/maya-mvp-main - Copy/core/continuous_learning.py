import datetime
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
LOG_DIR = BASE_DIR / "logs"
RETRAINING_QUEUE = LOG_DIR / "retraining_queue.jsonl"
MODEL_STATE = LOG_DIR / "model_update_state.json"


def append_json_line(path: Path, payload: dict):
    LOG_DIR.mkdir(exist_ok=True)
    with path.open("a", encoding="utf-8") as handle:
        handle.write(__import__("json").dumps(payload) + "\n")


def queue_for_learning(event):
    payload = {
        "queued_at": datetime.datetime.utcnow().isoformat(),
        "event_id": event.get("event_id"),
        "attack_type": event.get("type"),
        "severity": event.get("severity"),
        "attacker_ip": event.get("attacker_ip"),
        "campaign_fingerprint": event.get("correlation", {}).get("campaign_fingerprint"),
        "explanation": event.get("explanation", []),
    }
    append_json_line(RETRAINING_QUEUE, payload)
    return {
        "queue_path": str(RETRAINING_QUEUE),
        "queued": True,
        "schedule": "weekly",
    }
