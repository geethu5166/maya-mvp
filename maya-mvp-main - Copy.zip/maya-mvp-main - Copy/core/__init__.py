"""Core platform services for MAYA."""
